<?php
$type = "mysql";
$servername = "mysql";
$username = "Nom";
$password = "W@ySnfUwqa|%kY$1";
$database = "mtgDB";
